package ivgroup.master.database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasterDatabaseNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasterDatabaseNewApplication.class, args);
	}

}
