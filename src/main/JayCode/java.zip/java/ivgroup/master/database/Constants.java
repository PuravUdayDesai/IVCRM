package ivgroup.master.database;

public class Constants {
	public final static String URL_TO_REQUEST="http://localhost:8080";
	public final static String URL_PUBLIC_REQUEST="*";
}
